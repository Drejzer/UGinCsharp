﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UGCli
    {
    /// <summary>
    /// Implements teh ability to move
    /// </summary>
    interface IMobile
        {
        int Move(int dir);
        }
    }

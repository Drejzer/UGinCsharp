﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SQLite;
using System.Text;
using System.Threading.Tasks;

namespace UGinCsharp
    {
    /// <summary>
    /// Deals with combat encounters
    /// </summary>
    class Encounter
        {

        }
    }
